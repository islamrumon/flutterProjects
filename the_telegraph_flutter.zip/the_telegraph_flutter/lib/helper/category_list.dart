
class cat{
  int id;
  String name;
  cat({this.id,this.name});
}

//add data in this list
List<cat> catList=  <cat>[
  cat(
    id: 1,
    name: "TopList",
  ),
  cat(
    id: 2,
    name: "Pakisthan",
  ),
  cat(
    id: 3,
    name: "India",
  ),
  cat(
    id: 4,
    name: "Bangladesh",
  ),
  cat(
    id: 5,
    name: "Iran",
  ),
  cat(
    id: 6,
    name: "Iraq",
  ),
  cat(
    id: 7,
    name: "Story",
  ),
  cat(
    id: 8,
    name: "World War",
  ),
  cat(
    id: 9,
    name: "Islam",
  ),
  cat(
    id: 10,
    name: "Politics",
  )
];