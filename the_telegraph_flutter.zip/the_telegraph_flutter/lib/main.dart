import 'package:flutter/material.dart';
import 'package:the_telegraph_flutter/screens/home_screen.dart';

//void main() => runApp(SettingScreen());
void main() => runApp(HomeScreen());


