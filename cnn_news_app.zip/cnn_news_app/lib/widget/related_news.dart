import 'package:flutter/material.dart';
import 'package:cnn_news_app/helper/news.dart';
import 'package:cnn_news_app/widget/grid_view.dart';

class RelatedNews extends StatefulWidget {
  @override
  _RelatedNewsState createState() => _RelatedNewsState();
}

class _RelatedNewsState extends State<RelatedNews> {
  @override
  Widget build(BuildContext context) {
//    return  GridView.builder(
//              itemCount: listOfNews.length,
//              gridDelegate:
//              SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount: 2),
//              itemBuilder: (BuildContext context, int index) {
//                return GridNews(
//                  title: listOfNews[index].title,
//                  image: listOfNews[index].image,
//                  location: listOfNews[index].location.toString(),
//                  time: listOfNews[index].time.toString(),
//                  detials: listOfNews[index].detials.toString(),
//                );
//              });


  }
}

