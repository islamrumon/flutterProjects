
import 'package:cnn_news_app/screen/bookmark_screen.dart';
import 'package:cnn_news_app/screen/search_screen.dart';
import 'package:cnn_news_app/screen/setting_screen.dart';
import 'package:cnn_news_app/screen/tab_view_screen.dart';
import 'package:flutter/material.dart';


//final pageSource = [
//  TabViewScreen(),
//  SearchScrenn(),
//  BookmarkScreen(),
//  SettingScreen(),
//];
final pageSource =[
  TabViewScreen(),
  SearchScrenn(),
  BookmarkScreen(),
  SettingScreen(),
];

